import UIKit
import PlaygroundSupport

// 設定參考圖與背景色 -------------------------------------------
//let image = UIImage(named: "pikachu.jpg")
//let imageView = UIImageView(image: image)

//let backgroundView = UIView(frame: imageView.frame)
//backgroundView.addSubview(imageView)

// 完成後將上四行參考圖案變為註解，改為下面兩行的白色底圖。
let backgroundView = UIView(frame: CGRect(x: 0, y: 0, width: 400, height: 400))
backgroundView.backgroundColor = UIColor.white

// 下面兩行為製作圖像時使用的藍色半透明圖，設定alpha和RGBaSettingBlue用
let alphaDesignFirst: CGFloat = 0.5
let RGBaSettingBlue = UIColor(red: 0, green: 0, blue: 1, alpha: alphaDesignFirst)

// 下面兩行為Pikachu的顏色，設定alphaPikachuColor和RGBaSettingPikachColor用
let alphaPikachuColor: CGFloat = 1
let RGBaSettingPikachuColor = UIColor(red: 249/255, green: 212/255, blue: 34/255, alpha: alphaPikachuColor).cgColor
// (原始pikachu Color RGB設定為249/255, 212/255, 34/255)

// 下面兩行為陰影的顏色，設定alphaShadowColor和RGBaSettingShadow用
let alphaShadowColor: CGFloat = 1
let RGBaSettingShadowColor = UIColor(red: 226/255, green: 148/255, blue: 37/255, alpha: alphaShadowColor).cgColor

// 下面兩行為Stroke的顏色，設定alpha和shapeStrokeColor用
let alphaStrokeColor: CGFloat = 1
let shapeStrokeColor = UIColor(red: 0, green: 0, blue: 0, alpha: alphaStrokeColor).cgColor

// 設定外框線(方便修改)
let strokeLinesetting: CGFloat = 1.9

// -----------------------------------------------------------

// 使用UIBezierPath繪製圖案
// 右耳
//let earView1 = UIView(frame: imageView.frame)
let earView1 = UIView(frame: backgroundView.frame)
//earView1.backgroundColor = RGBaSettingBlue // 檢視設計時藍底圖

let earPath1 = UIBezierPath()
earPath1.move(to: CGPoint(x: 0, y: 25))
earPath1.addQuadCurve(to: CGPoint(x: 121, y: 88), controlPoint: CGPoint(x: 70, y: 33))
earPath1.addQuadCurve(to: CGPoint(x: 100, y: 104), controlPoint: CGPoint(x: 110, y: 94))
earPath1.addQuadCurve(to: CGPoint(x: 0, y: 25), controlPoint: CGPoint(x: 45, y: 87))

let earShape1 = CAShapeLayer()
earShape1.path = earPath1.cgPath
//earView1.layer.mask = earShape1

earShape1.fillColor = RGBaSettingPikachuColor
earShape1.strokeColor = shapeStrokeColor
earShape1.lineWidth = strokeLinesetting
earView1.layer.addSublayer(earShape1)
//上列這行與earView1.backgroundColor切換使用（藍底圖＆完成視圖)
backgroundView.addSubview(earView1)

// 右耳黑色部分
//let earTopView1 = UIView(frame: imageView.frame)
let earTopView1 = UIView(frame: backgroundView.frame)
//earTopView1.backgroundColor = RGBaSettingBlue

let earTopPath1 = UIBezierPath()
earTopPath1.move(to: CGPoint(x: 0, y: 25))
earTopPath1.addQuadCurve(to: CGPoint(x: 43, y: 37), controlPoint: CGPoint(x: 45, y: 33))
earTopPath1.addQuadCurve(to: CGPoint(x: 48, y: 76), controlPoint: CGPoint(x: 45, y: 76))
earTopPath1.addQuadCurve(to: CGPoint(x: 0, y: 25), controlPoint: CGPoint(x: 24, y: 55))

let earTopShape1 = CAShapeLayer()
earTopShape1.path = earTopPath1.cgPath
//earTopView1.layer.mask = earTopShape1

earTopShape1.fillColor = UIColor(red: 0, green: 0, blue: 0, alpha: alphaPikachuColor).cgColor
earTopShape1.strokeColor = shapeStrokeColor
earTopShape1.lineWidth = strokeLinesetting
earTopView1.layer.addSublayer(earTopShape1)
backgroundView.addSubview(earTopView1)

// 左耳
//let earView2 = UIView(frame: imageView.frame)
let earView2 = UIView(frame: backgroundView.frame)
//earView2.backgroundColor = RGBaSettingBlue

let earPath2 = UIBezierPath()
earPath2.move(to: CGPoint(x: 240, y: 0))
earPath2.addQuadCurve(to: CGPoint(x: 222, y: 140), controlPoint: CGPoint(x: 255, y: 85))
earPath2.addQuadCurve(to: CGPoint(x: 206, y: 113), controlPoint: CGPoint(x: 213, y: 120))
earPath2.addQuadCurve(to: CGPoint(x: 240, y: 0), controlPoint: CGPoint(x: 200, y: 65))

let earShape2 = CAShapeLayer()
earShape2.path = earPath2.cgPath
//earView2.layer.mask = earShape2

earShape2.fillColor = RGBaSettingPikachuColor
earShape2.strokeColor = shapeStrokeColor
earShape2.lineWidth = strokeLinesetting
earView2.layer.addSublayer(earShape2)
backgroundView.addSubview(earView2)

// 左耳黑色部分
//let earTopView2 = UIView(frame: imageView.frame)
let earTopView2 = UIView(frame: backgroundView.frame)
//earTopView2.backgroundColor = RGBaSettingBlue

let earTopPath2 = UIBezierPath()
earTopPath2.move(to: CGPoint(x: 240, y: 0))
earTopPath2.addQuadCurve(to: CGPoint(x: 244, y: 61), controlPoint: CGPoint(x: 247, y: 30))
earTopPath2.addQuadCurve(to: CGPoint(x: 222, y: 34), controlPoint: CGPoint(x: 231, y: 43))
earTopPath2.addQuadCurve(to: CGPoint(x: 240, y: 0), controlPoint: CGPoint(x: 226, y: 24))

let earTopShape2 = CAShapeLayer()
earTopShape2.path = earTopPath2.cgPath
earTopView2.layer.mask = earTopShape2

earTopShape2.fillColor = UIColor(red: 0, green: 0, blue: 0, alpha: alphaPikachuColor).cgColor
earTopShape2.strokeColor = shapeStrokeColor
earTopShape2.lineWidth = strokeLinesetting
earTopView2.layer.addSublayer(earTopShape2)
backgroundView.addSubview(earTopView2)

// 頭
//let headView = UIView(frame: imageView.frame)
let headView = UIView(frame: backgroundView.frame)
//headView.backgroundColor = RGBaSettingBlue

let headPath = UIBezierPath()
headPath.move(to: CGPoint(x: 121, y: 88))
headPath.addQuadCurve(to: CGPoint(x: 222, y: 137), controlPoint: CGPoint(x: 194, y: 73))
headPath.addQuadCurve(to: CGPoint(x: 214, y: 189), controlPoint: CGPoint(x: 226, y: 144))
headPath.addQuadCurve(to: CGPoint(x: 214, y: 199), controlPoint: CGPoint(x: 215, y: 190))
headPath.addQuadCurve(to: CGPoint(x: 171, y: 237), controlPoint: CGPoint(x: 200, y: 231))
headPath.addQuadCurve(to: CGPoint(x: 81, y: 208), controlPoint: CGPoint(x: 130, y: 240))
headPath.addQuadCurve(to: CGPoint(x: 70, y: 160), controlPoint: CGPoint(x: 62, y: 170))
headPath.addQuadCurve(to: CGPoint(x: 79, y: 145), controlPoint: CGPoint(x: 71, y: 157))
headPath.addQuadCurve(to: CGPoint(x: 121, y: 88), controlPoint: CGPoint(x: 96, y: 90))

let headShape = CAShapeLayer()
headShape.path = headPath.cgPath
//headView.layer.mask = headShape

headShape.fillColor = RGBaSettingPikachuColor
//headShape.strokeColor = shapeStrokeColor
//headShape.lineWidth = strokeLinesetting
headView.layer.addSublayer(headShape)
backgroundView.addSubview(headView)

// 頭無連結的線條
//let headLineView = UIView(frame: imageView.frame)
let headLineView = UIView(frame: backgroundView.frame)
//headLineView.backgroundColor = RGBaSettingBlue

let headLinePath = UIBezierPath()
headLinePath.move(to: CGPoint(x: 116, y: 88))
headLinePath.addQuadCurve(to: CGPoint(x: 214, y: 120), controlPoint: CGPoint(x: 180, y: 76))

headLinePath.move(to: CGPoint(x: 220, y: 132))
headLinePath.addQuadCurve(to: CGPoint(x: 219, y: 168), controlPoint: CGPoint(x: 225, y: 150))

headLinePath.addQuadCurve(to: CGPoint(x: 213, y: 199), controlPoint: CGPoint(x: 215, y: 190))
headLinePath.addQuadCurve(to: CGPoint(x: 170, y: 235), controlPoint: CGPoint(x: 200, y: 231))

headLinePath.move(to: CGPoint(x: 81, y: 208))
headLinePath.addQuadCurve(to: CGPoint(x: 73, y: 153), controlPoint: CGPoint(x: 62, y: 170))
headLinePath.addQuadCurve(to: CGPoint(x: 86, y: 126), controlPoint: CGPoint(x: 85, y: 132))
headLinePath.addQuadCurve(to: CGPoint(x: 102, y: 98), controlPoint: CGPoint(x: 92, y: 110))

let headLineShape = CAShapeLayer()
headLineShape.path = headLinePath.cgPath
//headLineView.layer.mask = headLineShape

headLineShape.fillColor = UIColor.clear.cgColor
headLineShape.strokeColor = shapeStrokeColor
headLineShape.lineWidth = strokeLinesetting
headLineView.layer.addSublayer(headLineShape)
backgroundView.addSubview(headLineView)

// 身體
//let bodyView = UIView(frame: imageView.frame)
let bodyView = UIView(frame: backgroundView.frame)
//bodyView.backgroundColor = RGBaSettingBlue

let bodyPath = UIBezierPath()
bodyPath.move(to: CGPoint(x: 196, y: 224))
bodyPath.addQuadCurve(to: CGPoint(x: 200, y: 336), controlPoint: CGPoint(x: 188, y: 278))
bodyPath.addQuadCurve(to: CGPoint(x: 168, y: 383), controlPoint: CGPoint(x: 220, y: 380))
bodyPath.addQuadCurve(to: CGPoint(x: 111, y: 372), controlPoint: CGPoint(x: 140, y: 378))
bodyPath.addQuadCurve(to: CGPoint(x: 79, y: 375), controlPoint: CGPoint(x: 96, y: 370))
bodyPath.addQuadCurve(to: CGPoint(x: 41, y: 324), controlPoint: CGPoint(x: 20, y: 370))
bodyPath.addQuadCurve(to: CGPoint(x: 81, y: 208), controlPoint: CGPoint(x: 63, y: 264))
bodyPath.addQuadCurve(to: CGPoint(x: 196, y: 224), controlPoint: CGPoint(x: 165, y: 255))

let bodyShape = CAShapeLayer()
bodyShape.path = bodyPath.cgPath
//bodyView.layer.mask = bodyShape

bodyShape.fillColor = RGBaSettingPikachuColor
//bodyShape.strokeColor = shapeStrokeColor
//bodyShape.lineWidth = strokeLinesetting
bodyView.layer.addSublayer(bodyShape)
backgroundView.addSubview(bodyView)

// 身體無連結的線條
//let bodyLineView = UIView(frame: imageView.frame)
let bodyLineView = UIView(frame: backgroundView.frame)
//bodyLineView.backgroundColor = RGBaSettingBlue

let bodyLinePath = UIBezierPath()
bodyLinePath.move(to: CGPoint(x: 63, y: 264))
bodyLinePath.addQuadCurve(to: CGPoint(x: 41, y: 324), controlPoint: CGPoint(x: 51, y: 294))
bodyLinePath.addQuadCurve(to: CGPoint(x: 59, y: 371), controlPoint: CGPoint(x: 25, y: 360))

bodyLinePath.move(to: CGPoint(x: 69, y: 374))
bodyLinePath.addQuadCurve(to: CGPoint(x: 136, y: 370), controlPoint: CGPoint(x: 130, y: 369))

bodyLinePath.move(to: CGPoint(x: 112, y: 371))
bodyLinePath.addQuadCurve(to: CGPoint(x: 186, y: 379), controlPoint: CGPoint(x: 160, y: 385))

bodyLinePath.move(to: CGPoint(x: 194, y: 376))
bodyLinePath.addQuadCurve(to: CGPoint(x: 200, y: 336), controlPoint: CGPoint(x: 215, y: 361))
bodyLinePath.addQuadCurve(to: CGPoint(x: 194, y: 276), controlPoint: CGPoint(x: 190, y: 300))
bodyLinePath.addLine(to: CGPoint(x: 189, y: 278))

bodyLinePath.move(to: CGPoint(x: 262, y: 186))
bodyLinePath.addLine(to: CGPoint(x: 258, y: 196))

let bodyLineShape = CAShapeLayer()
bodyLineShape.path = bodyLinePath.cgPath
//bodyLineView.layer.mask = bodyLineShape

bodyLineShape.fillColor = UIColor.clear.cgColor
bodyLineShape.strokeColor = shapeStrokeColor
bodyLineShape.lineWidth = strokeLinesetting
bodyLineView.layer.addSublayer(bodyLineShape)
backgroundView.addSubview(bodyLineView)

// 右手
//let handView1 = UIView(frame: imageView.frame)
let handView1 = UIView(frame: backgroundView.frame)
//handView1.backgroundColor = RGBaSettingBlue

let handPath1 = UIBezierPath()
handPath1.move(to: CGPoint(x: 112, y: 252))

handPath1.addQuadCurve(to: CGPoint(x: 46, y: 253), controlPoint: CGPoint(x: 65, y: 274))
handPath1.addQuadCurve(to: CGPoint(x: 46, y: 213), controlPoint: CGPoint(x: 27, y: 234))
handPath1.addQuadCurve(to: CGPoint(x: 99, y: 210), controlPoint: CGPoint(x: 67, y: 200))
handPath1.addQuadCurve(to: CGPoint(x: 118, y: 223), controlPoint: CGPoint(x: 108, y: 213))
handPath1.addQuadCurve(to: CGPoint(x: 124, y: 225), controlPoint: CGPoint(x: 121, y: 224))
handPath1.addQuadCurve(to: CGPoint(x: 123, y: 229), controlPoint: CGPoint(x: 123, y: 226))
handPath1.addQuadCurve(to: CGPoint(x: 130, y: 235), controlPoint: CGPoint(x: 127, y: 230))
handPath1.addQuadCurve(to: CGPoint(x: 124, y: 236), controlPoint: CGPoint(x: 125, y: 236))
handPath1.addQuadCurve(to: CGPoint(x: 128, y: 241), controlPoint: CGPoint(x: 125, y: 238))
handPath1.addQuadCurve(to: CGPoint(x: 122, y: 242), controlPoint: CGPoint(x: 124, y: 242))
handPath1.addQuadCurve(to: CGPoint(x: 124, y: 247), controlPoint: CGPoint(x: 125, y: 246))
handPath1.addQuadCurve(to: CGPoint(x: 119, y: 247), controlPoint: CGPoint(x: 126, y: 248))
handPath1.addQuadCurve(to: CGPoint(x: 119, y: 254), controlPoint: CGPoint(x: 120, y: 251))
handPath1.addQuadCurve(to: CGPoint(x: 112, y: 252), controlPoint: CGPoint(x: 116, y: 252))

let handShape1 = CAShapeLayer()
handShape1.path = handPath1.cgPath
//handView1.layer.mask = handShape1

handShape1.fillColor = RGBaSettingPikachuColor
handShape1.strokeColor = shapeStrokeColor
handShape1.lineWidth = strokeLinesetting
handView1.layer.addSublayer(handShape1)
backgroundView.addSubview(handView1)

// 左手
//let handView2 = UIView(frame: imageView.frame)
let handView2 = UIView(frame: backgroundView.frame)
//handView2.backgroundColor = RGBaSettingBlue

let handPath2 = UIBezierPath()
handPath2.move(to: CGPoint(x: 196, y: 224))
handPath2.addQuadCurve(to: CGPoint(x: 263, y: 185), controlPoint: CGPoint(x: 215, y: 179))
handPath2.addLine(to: CGPoint(x: 261, y: 191))
handPath2.addLine(to: CGPoint(x: 269, y: 197))
handPath2.addLine(to: CGPoint(x: 263, y: 199))
handPath2.addLine(to: CGPoint(x: 266, y: 203))
handPath2.addLine(to: CGPoint(x: 262, y: 205))
handPath2.addLine(to: CGPoint(x: 264, y: 209))
handPath2.addLine(to: CGPoint(x: 259, y: 210))
handPath2.addLine(to: CGPoint(x: 260, y: 215))
handPath2.addLine(to: CGPoint(x: 253, y: 214))
handPath2.addQuadCurve(to: CGPoint(x: 193, y: 276), controlPoint: CGPoint(x: 229, y: 255))
handPath2.addQuadCurve(to: CGPoint(x: 195, y: 224), controlPoint: CGPoint(x: 187, y: 255))

let handShape2 = CAShapeLayer()
handShape2.path = handPath2.cgPath
//handView2.layer.mask = handShape2

handShape2.fillColor = RGBaSettingPikachuColor
handShape2.strokeColor = shapeStrokeColor
handShape2.lineWidth = strokeLinesetting
handView2.layer.addSublayer(handShape2)
backgroundView.addSubview(handView2)

// 右腳
//let footView1 = UIView(frame: imageView.frame)
let footView1 = UIView(frame: backgroundView.frame)
//footView1.backgroundColor = RGBaSettingBlue

let footPath1 = UIBezierPath()
footPath1.move(to: CGPoint(x: 48, y: 366))
footPath1.addQuadCurve(to: CGPoint(x: 22, y: 382), controlPoint: CGPoint(x: 35, y: 369))
footPath1.addQuadCurve(to: CGPoint(x: 27, y: 385), controlPoint: CGPoint(x: 24, y: 385))
footPath1.addQuadCurve(to: CGPoint(x: 73, y: 380), controlPoint: CGPoint(x: 50, y: 385))
footPath1.addQuadCurve(to: CGPoint(x: 82, y: 374), controlPoint: CGPoint(x: 85, y: 380))
footPath1.addQuadCurve(to: CGPoint(x: 48, y: 366), controlPoint: CGPoint(x: 66, y: 374))
footPath1.close()

let footShape1 = CAShapeLayer()
footShape1.path = footPath1.cgPath
//footView1.layer.mask = footShape1

footShape1.fillColor = RGBaSettingPikachuColor
//footShape1.strokeColor = shapeStrokeColor
//footShape1.lineWidth = strokeLinesetting
footView1.layer.addSublayer(footShape1)
backgroundView.addSubview(footView1)

// 右腳無線條連結
//let footLineView1 = UIView(frame: imageView.frame)
let footLineView1 = UIView(frame: backgroundView.frame)
//footLineView1.backgroundColor = RGBaSettingBlue

let footLinePath1 = UIBezierPath()
footLinePath1.move(to: CGPoint(x: 48, y: 367))
footLinePath1.addQuadCurve(to: CGPoint(x: 24, y: 382), controlPoint: CGPoint(x: 20, y: 377))

footLinePath1.move(to: CGPoint(x: 38, y: 375))
footLinePath1.addQuadCurve(to: CGPoint(x: 28, y: 385), controlPoint: CGPoint(x: 17, y: 385))

footLinePath1.move(to: CGPoint(x: 42, y: 378))
footLinePath1.addQuadCurve(to: CGPoint(x: 36, y: 386), controlPoint: CGPoint(x: 18, y: 388))
//footLinePath1.addQuadCurve(to: CGPoint(x: 44, y: 384), controlPoint: CGPoint(x: 13, y: 388))
footLinePath1.addLine(to: CGPoint(x: 72, y: 381))
footLinePath1.addQuadCurve(to: CGPoint(x: 79, y: 371), controlPoint: CGPoint(x: 84, y: 380))

let footLineShape1 = CAShapeLayer()
footLineShape1.path = footLinePath1.cgPath
//footLineView1.layer.mask = footLineShape1

footLineShape1.fillColor = UIColor.clear.cgColor
footLineShape1.strokeColor = shapeStrokeColor
footLineShape1.lineWidth = strokeLinesetting
footLineView1.layer.addSublayer(footLineShape1)
backgroundView.addSubview(footLineView1)

// 左腳
//let footView2 = UIView(frame: imageView.frame)
let footView2 = UIView(frame: backgroundView.frame)
//footView2.backgroundColor = RGBaSettingBlue

let footPath2 = UIBezierPath()
footPath2.move(to: CGPoint(x: 167, y: 381))
footPath2.addQuadCurve(to: CGPoint(x: 172, y: 387), controlPoint: CGPoint(x: 165, y: 385))
footPath2.addQuadCurve(to: CGPoint(x: 221, y: 399), controlPoint: CGPoint(x: 186, y: 392))
footPath2.addQuadCurve(to: CGPoint(x: 225, y: 393), controlPoint: CGPoint(x: 223, y: 393))
footPath2.addQuadCurve(to: CGPoint(x: 195, y: 374), controlPoint: CGPoint(x: 215, y: 380))
footPath2.addQuadCurve(to: CGPoint(x: 167, y: 381), controlPoint: CGPoint(x: 180, y: 382))
footPath2.close()

let footShape2 = CAShapeLayer()
footShape2.path = footPath2.cgPath
//footView2.layer.mask = footShape2

footShape2.fillColor = RGBaSettingPikachuColor
//footShape2.strokeColor = shapeStrokeColor
//footShape2.lineWidth = strokeLinesetting
footView2.layer.addSublayer(footShape2)
backgroundView.addSubview(footView2)

// 左腳無線條連結
//let footLineView2 = UIView(frame: imageView.frame)
let footLineView2 = UIView(frame: backgroundView.frame)
//footLineView2.backgroundColor = RGBaSettingBlue

let footLinePath2 = UIBezierPath()
footLinePath2.move(to: CGPoint(x: 195, y: 373))
footLinePath2.addQuadCurve(to: CGPoint(x: 224, y: 395), controlPoint: CGPoint(x: 232, y: 394))

footLinePath2.move(to: CGPoint(x: 208, y: 384))
footLinePath2.addQuadCurve(to: CGPoint(x: 221, y: 397), controlPoint: CGPoint(x: 230, y: 397))

footLinePath2.move(to: CGPoint(x: 203, y: 386))
footLinePath2.addQuadCurve(to: CGPoint(x: 203, y: 394), controlPoint: CGPoint(x: 238, y: 405))
footLinePath2.addLine(to: CGPoint(x: 177, y: 388))
footLinePath2.addQuadCurve(to: CGPoint(x: 167, y: 379), controlPoint: CGPoint(x: 160, y: 385))

let footLineShape2 = CAShapeLayer()
footLineShape2.path = footLinePath2.cgPath
//footLineView2.layer.mask = footLineShape2

footLineShape2.fillColor = UIColor.clear.cgColor
footLineShape2.strokeColor = shapeStrokeColor
footLineShape2.lineWidth = strokeLinesetting
footLineView2.layer.addSublayer(footLineShape2)
backgroundView.addSubview(footLineView2)

// 尾巴
//let tailView = UIView(frame: imageView.frame)
let tailView = UIView(frame: backgroundView.frame)
//tailView.backgroundColor = RGBaSettingBlue

let tailPath = UIBezierPath()
tailPath.move(to: CGPoint(x: 242, y: 218))
tailPath.addQuadCurve(to: CGPoint(x: 379, y: 248), controlPoint: CGPoint(x: 320, y: 220))
tailPath.addLine(to: CGPoint(x: 329, y: 298))
tailPath.addLine(to: CGPoint(x: 262, y: 279))
tailPath.addLine(to: CGPoint(x: 239, y: 316))
tailPath.addLine(to: CGPoint(x: 224, y: 311))
tailPath.addLine(to: CGPoint(x: 222, y: 343))
tailPath.addLine(to: CGPoint(x: 200, y: 336))
tailPath.addLine(to: CGPoint(x: 196, y: 323))
tailPath.addLine(to: CGPoint(x: 208, y: 324))
tailPath.addLine(to: CGPoint(x: 205, y: 287))
tailPath.addLine(to: CGPoint(x: 228, y: 291))
tailPath.close()

let tailShape = CAShapeLayer()
tailShape.path = tailPath.cgPath
//tailView.layer.mask = tailShape

tailShape.fillColor = RGBaSettingPikachuColor
tailShape.strokeColor = shapeStrokeColor
tailShape.lineWidth = strokeLinesetting
tailView.layer.addSublayer(tailShape)
backgroundView.addSubview(tailView)

// 尾巴前端
//let frontTailView = UIView(frame: imageView.frame)
let frontTailView = UIView(frame: backgroundView.frame)
//frontTailView.backgroundColor = RGBaSettingBlue

let frontTailPath = UIBezierPath()
frontTailPath.move(to: CGPoint(x: 223, y: 319))
frontTailPath.addLine(to: CGPoint(x: 221, y: 343))
frontTailPath.addLine(to: CGPoint(x: 222, y: 343))
frontTailPath.addLine(to: CGPoint(x: 222, y: 343))
frontTailPath.addLine(to: CGPoint(x: 200, y: 336))
frontTailPath.addLine(to: CGPoint(x: 196, y: 323))
frontTailPath.addLine(to: CGPoint(x: 208, y: 324))
frontTailPath.addLine(to: CGPoint(x: 208, y: 315))
frontTailPath.addLine(to: CGPoint(x: 211, y: 320))
frontTailPath.addLine(to: CGPoint(x: 213, y: 313))
frontTailPath.addLine(to: CGPoint(x: 215, y: 320))
frontTailPath.addLine(to: CGPoint(x: 218, y: 314))
frontTailPath.addLine(to: CGPoint(x: 219, y: 321))
frontTailPath.addLine(to: CGPoint(x: 221, y: 316))
frontTailPath.close()

let frontTailShape = CAShapeLayer()
frontTailShape.path = frontTailPath.cgPath
//frontTailView.layer.mask = frontTailShape

frontTailShape.fillColor = UIColor(red: 128/255, green: 36/255, blue: 4/255, alpha: alphaPikachuColor).cgColor
//frontTailShape.strokeColor = shapeStrokeColor
//frontTailShape.lineWidth = strokeLinesetting
frontTailView.layer.addSublayer(frontTailShape)
backgroundView.addSubview(frontTailView)

// 右眼(黑眼珠和白色瞳孔)
let aDegree : CGFloat = CGFloat.pi/180
let eyeView1 = UIView(frame: CGRect(x: 99, y: 124, width: 23, height: 25))
eyeView1.layer.cornerRadius = eyeView1.frame.width / 2
//eyeView1.backgroundColor = UIColor(red: 1, green: 0, blue: 0, alpha: alphaStrokeColor)
eyeView1.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: alphaStrokeColor)
eyeView1.transform = CGAffineTransform(rotationAngle: aDegree*30)
backgroundView.addSubview(eyeView1)

let eyePupilView1 = UIView(frame: CGRect(x: 110, y: 128, width: 10, height: 10))
eyePupilView1.layer.cornerRadius = eyePupilView1.frame.width / 2
eyePupilView1.backgroundColor = UIColor(red: 1, green: 1, blue: 1, alpha: alphaStrokeColor)
backgroundView.addSubview(eyePupilView1)

// 左眼(黑眼珠和白色瞳孔)
let eyeView2 = UIView(frame: CGRect(x: 180, y: 148, width: 23, height: 25))
eyeView2.layer.cornerRadius = eyeView2.frame.width / 2
//eyeView2.backgroundColor = UIColor(red: 1, green: 0, blue: 0, alpha: alphaStrokeColor)
eyeView2.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: alphaStrokeColor)
eyeView2.transform = CGAffineTransform(rotationAngle: -aDegree*28)
backgroundView.addSubview(eyeView2)

let eyePupilView2 = UIView(frame: CGRect(x: 185, y: 150, width: 10, height: 10))
eyePupilView2.layer.cornerRadius = eyePupilView2.frame.width / 2
eyePupilView2.backgroundColor = UIColor(red: 1, green: 1, blue: 1, alpha: alphaStrokeColor)
backgroundView.addSubview(eyePupilView2)

// 右腮紅
//let blushView1 = UIView(frame: imageView.frame)
let blushView1 = UIView(frame: backgroundView.frame)
//blushView1.backgroundColor = RGBaSettingBlue

let blushPath1 = UIBezierPath()
blushPath1.move(to: CGPoint(x: 79, y: 145))
blushPath1.addQuadCurve(to: CGPoint(x: 89, y: 168), controlPoint: CGPoint(x: 92, y: 150))
blushPath1.addQuadCurve(to: CGPoint(x: 72, y: 186), controlPoint: CGPoint(x: 87, y: 182))
blushPath1.addQuadCurve(to: CGPoint(x: 67, y: 168), controlPoint: CGPoint(x: 66, y: 170))
blushPath1.addQuadCurve(to: CGPoint(x: 79, y: 145), controlPoint: CGPoint(x: 67, y: 159))

let blushShape1 = CAShapeLayer()
blushShape1.path = blushPath1.cgPath
//blushView1.layer.mask = blushShape1

blushShape1.fillColor = UIColor(red: 243/255, green: 45/255, blue: 28/255, alpha: alphaPikachuColor).cgColor
blushShape1.strokeColor = shapeStrokeColor
blushShape1.lineWidth = strokeLinesetting
blushView1.layer.addSublayer(blushShape1)
backgroundView.addSubview(blushView1)

// 左腮紅
//let blushView2 = UIView(frame: imageView.frame)
let blushView2 = UIView(frame: backgroundView.frame)
//blushView2.backgroundColor = RGBaSettingBlue

let blushPath2 = UIBezierPath()
blushPath2.move(to: CGPoint(x: 215, y: 189))
blushPath2.addQuadCurve(to: CGPoint(x: 189, y: 208), controlPoint: CGPoint(x: 200, y: 183))
blushPath2.addQuadCurve(to: CGPoint(x: 196, y: 224), controlPoint: CGPoint(x: 184, y: 220))
blushPath2.addQuadCurve(to: CGPoint(x: 211, y: 209), controlPoint: CGPoint(x: 203, y: 221))
blushPath2.addQuadCurve(to: CGPoint(x: 215, y: 189), controlPoint: CGPoint(x: 211, y: 212))

let blushShape2 = CAShapeLayer()
blushShape2.path = blushPath2.cgPath
//blushView2.layer.mask = blushShape2

blushShape2.fillColor = UIColor(red: 255/255, green: 64/255, blue: 0, alpha: alphaPikachuColor).cgColor
blushShape2.strokeColor = shapeStrokeColor
blushShape2.lineWidth = strokeLinesetting
blushView2.layer.addSublayer(blushShape2)
backgroundView.addSubview(blushView2)

// 鼻子
let noseView = UIView(frame: CGRect(x: 142, y: 151, width: 10, height: 4))
noseView.layer.cornerRadius = noseView.frame.width / 2
noseView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: alphaStrokeColor)
noseView.transform = CGAffineTransform(rotationAngle: aDegree*15)
backgroundView.addSubview(noseView)

// 嘴巴
//let mouthView = UIView(frame: imageView.frame)
let mouthView = UIView(frame: backgroundView.frame)
//mouthView.backgroundColor = RGBaSettingBlue

let mouthPath = UIBezierPath()
mouthPath.move(to: CGPoint(x: 123, y: 164))
mouthPath.addQuadCurve(to: CGPoint(x: 145, y: 160), controlPoint: CGPoint(x: 128, y: 165))
mouthPath.addQuadCurve(to: CGPoint(x: 166, y: 176), controlPoint: CGPoint(x: 159, y: 175))
mouthPath.addQuadCurve(to: CGPoint(x: 145, y: 209), controlPoint: CGPoint(x: 154, y: 200))
mouthPath.addQuadCurve(to: CGPoint(x: 123, y: 204), controlPoint: CGPoint(x: 129, y: 225))
mouthPath.addQuadCurve(to: CGPoint(x: 123, y: 164), controlPoint: CGPoint(x: 118, y: 165))

let mouthShape = CAShapeLayer()
mouthShape.path = mouthPath.cgPath
//mouthView.layer.mask = mouthShape

mouthShape.fillColor = UIColor(red: 138/255, green: 4/255, blue: 23/255, alpha: alphaPikachuColor).cgColor
mouthShape.strokeColor = shapeStrokeColor
mouthShape.lineWidth = strokeLinesetting
mouthView.layer.addSublayer(mouthShape)
backgroundView.addSubview(mouthView)

// 嘴巴上緣部分
//let mouthTopView = UIView(frame: imageView.frame)
let mouthTopView = UIView(frame: backgroundView.frame)
//mouthTopView.backgroundColor = RGBaSettingBlue

let mouthTopPath = UIBezierPath()
mouthTopPath.move(to: CGPoint(x: 119, y: 160))
mouthTopPath.addQuadCurve(to: CGPoint(x: 121, y: 164), controlPoint: CGPoint(x: 117, y: 161))
mouthTopPath.addQuadCurve(to: CGPoint(x: 145, y: 160), controlPoint: CGPoint(x: 117, y: 169))
mouthTopPath.addQuadCurve(to: CGPoint(x: 167, y: 176), controlPoint: CGPoint(x: 159, y: 175))
mouthTopPath.addQuadCurve(to: CGPoint(x: 171, y: 174), controlPoint: CGPoint(x: 160, y: 178))

let mouthTopShape = CAShapeLayer()
mouthTopShape.path = mouthTopPath.cgPath
//mouthView.layer.mask = mouthTopShape

mouthTopShape.fillColor = UIColor.clear.cgColor
mouthTopShape.strokeColor = shapeStrokeColor
mouthTopShape.lineWidth = strokeLinesetting
mouthTopView.layer.addSublayer(mouthTopShape)
backgroundView.addSubview(mouthTopView)

// 嘴巴陰影
//let mouthShadowView = UIView(frame: imageView.frame)
let mouthShadowView = UIView(frame: backgroundView.frame)
//mouthShadowView.backgroundColor = RGBaSettingBlue

let mouthShadowPath = UIBezierPath()
mouthShadowPath.move(to: CGPoint(x: 121, y: 175))
mouthShadowPath.addQuadCurve(to: CGPoint(x: 160, y: 187), controlPoint: CGPoint(x: 150, y: 163))
mouthShadowPath.addLine(to: CGPoint(x: 157, y: 192))
mouthShadowPath.addQuadCurve(to: CGPoint(x: 121, y: 183), controlPoint: CGPoint(x: 145, y: 171))
mouthShadowPath.close()

let mouthShadowShape = CAShapeLayer()
mouthShadowShape.path = mouthShadowPath.cgPath
//mouthShadowView.layer.mask = mouthShadowShape

mouthShadowShape.fillColor = UIColor(red: 184/255, green: 2/255, blue: 42/255, alpha: alphaPikachuColor).cgColor
//mouthShadowShape.strokeColor = shapeStrokeColor
//mouthShadowShape.lineWidth = strokeLinesetting
mouthShadowView.layer.addSublayer(mouthShadowShape)
backgroundView.addSubview(mouthShadowView)

// 舌頭
//let tongueView = UIView(frame: imageView.frame)
let tongueView = UIView(frame: backgroundView.frame)
//tongueView.backgroundColor = RGBaSettingBlue

let tonguePath = UIBezierPath()
tonguePath.move(to: CGPoint(x: 121, y: 175))
tonguePath.addQuadCurve(to: CGPoint(x: 160, y: 187), controlPoint: CGPoint(x: 150, y: 161))
tonguePath.addQuadCurve(to: CGPoint(x: 145, y: 209), controlPoint: CGPoint(x: 154, y: 200))
tonguePath.addQuadCurve(to: CGPoint(x: 123, y: 204), controlPoint: CGPoint(x: 129, y: 225))
tonguePath.addQuadCurve(to: CGPoint(x: 121, y: 175), controlPoint: CGPoint(x: 120, y: 190))

let tongueShape = CAShapeLayer()
tongueShape.path = tonguePath.cgPath
//tongueView.layer.mask = tongueShape

tongueShape.fillColor = UIColor(red: 237/255, green: 84/255, blue: 96/255, alpha: alphaPikachuColor).cgColor
tongueShape.strokeColor = shapeStrokeColor
tongueShape.lineWidth = strokeLinesetting
tongueView.layer.addSublayer(tongueShape)
backgroundView.addSubview(tongueView)

// 陰影全部放在一起處理(此部分採直接抓感覺繪製)
//let shadowView = UIView(frame: imageView.frame)
let shadowView = UIView(frame: backgroundView.frame)
//shadowView.backgroundColor = RGBaSettingBluetseng690130


// 右耳陰影
let shadowPath = UIBezierPath()
shadowPath.move(to: CGPoint(x: 101, y: 98))
shadowPath.addLine(to: CGPoint(x: 46, y: 64))
shadowPath.addLine(to: CGPoint(x: 47, y: 74))
shadowPath.addQuadCurve(to: CGPoint(x: 98, y: 102), controlPoint: CGPoint(x: 68, y: 93))
shadowPath.addQuadCurve(to: CGPoint(x: 101, y: 98), controlPoint: CGPoint(x: 99, y: 101))
shadowPath.close()

// 左耳陰影
shadowPath.move(to: CGPoint(x: 222, y: 137))
shadowPath.addQuadCurve(to: CGPoint(x: 242, y: 78), controlPoint: CGPoint(x: 237, y: 118))
shadowPath.addQuadCurve(to: CGPoint(x: 220, y: 128), controlPoint: CGPoint(x: 228, y: 115))
//shadowPath.addLine(to: CGPoint(x: 220, y: 128))
shadowPath.close()

// 下巴陰影
shadowPath.move(to: CGPoint(x: 129, y: 231))
shadowPath.addQuadCurve(to: CGPoint(x: 151, y: 235), controlPoint: CGPoint(x: 138, y: 233))
shadowPath.addQuadCurve(to: CGPoint(x: 134, y: 243), controlPoint: CGPoint(x: 142, y: 243))
shadowPath.addQuadCurve(to: CGPoint(x: 129, y: 231), controlPoint: CGPoint(x: 130, y: 237))

// 右手陰影
shadowPath.move(to: CGPoint(x: 111, y: 251))
shadowPath.addQuadCurve(to: CGPoint(x: 45, y: 250), controlPoint: CGPoint(x: 65, y: 275))
shadowPath.addQuadCurve(to: CGPoint(x: 48, y: 247), controlPoint: CGPoint(x: 48, y: 246))
shadowPath.addLine(to: CGPoint(x: 94, y: 252))
shadowPath.addQuadCurve(to: CGPoint(x: 111, y: 251), controlPoint: CGPoint(x: 106, y: 250))

// 左手陰影
shadowPath.move(to: CGPoint(x: 186, y: 278))
shadowPath.addQuadCurve(to: CGPoint(x: 204, y: 255), controlPoint: CGPoint(x: 190, y: 262))
shadowPath.addLine(to: CGPoint(x: 243, y: 229))
shadowPath.addQuadCurve(to: CGPoint(x: 186, y: 278), controlPoint: CGPoint(x: 210, y: 270))

// 身體底部包含腳的陰影
shadowPath.move(to: CGPoint(x: 43, y: 384))
shadowPath.addLine(to: CGPoint(x: 72, y: 380))
shadowPath.addQuadCurve(to: CGPoint(x: 79, y: 372), controlPoint: CGPoint(x: 84, y: 380))
shadowPath.addLine(to: CGPoint(x: 109, y: 370))
shadowPath.addQuadCurve(to: CGPoint(x: 166, y: 381), controlPoint: CGPoint(x: 135, y: 379))
shadowPath.addQuadCurve(to: CGPoint(x: 178, y: 387), controlPoint: CGPoint(x: 162, y: 386))
shadowPath.addLine(to: CGPoint(x: 204, y: 379))
shadowPath.addLine(to: CGPoint(x: 195, y: 374))
shadowPath.addQuadCurve(to: CGPoint(x: 149, y: 355), controlPoint: CGPoint(x: 190, y: 356))
shadowPath.addQuadCurve(to: CGPoint(x: 108, y: 359), controlPoint: CGPoint(x: 126, y: 354))
shadowPath.addQuadCurve(to: CGPoint(x: 68, y: 356), controlPoint: CGPoint(x: 86, y: 363))
shadowPath.addQuadCurve(to: CGPoint(x: 47, y: 366), controlPoint: CGPoint(x: 38, y: 343))
shadowPath.addQuadCurve(to: CGPoint(x: 58, y: 371), controlPoint: CGPoint(x: 50, y: 369))
shadowPath.close()

// 尾巴陰影
shadowPath.move(to: CGPoint(x: 208, y: 315))
shadowPath.addLine(to: CGPoint(x: 211, y: 320))
shadowPath.addLine(to: CGPoint(x: 213, y: 313))
shadowPath.addLine(to: CGPoint(x: 215, y: 320))
shadowPath.addLine(to: CGPoint(x: 218, y: 314))
shadowPath.addLine(to: CGPoint(x: 219, y: 321))
shadowPath.addLine(to: CGPoint(x: 221, y: 316))
shadowPath.addLine(to: CGPoint(x: 223, y: 322))
shadowPath.addLine(to: CGPoint(x: 224, y: 310))
shadowPath.addLine(to: CGPoint(x: 239, y: 315))
shadowPath.addLine(to: CGPoint(x: 262, y: 278))
shadowPath.addLine(to: CGPoint(x: 329, y: 297))
shadowPath.addQuadCurve(to: CGPoint(x: 250, y: 247), controlPoint: CGPoint(x: 291, y: 264))
shadowPath.addLine(to: CGPoint(x: 235, y: 309))
shadowPath.addLine(to: CGPoint(x: 205, y: 288))
shadowPath.addLine(to: CGPoint(x: 208, y: 315))

let shadowShape = CAShapeLayer()
shadowShape.path = shadowPath.cgPath
//shadowView.layer.mask = tongueShape

shadowShape.fillColor = RGBaSettingShadowColor
//shadowShape.strokeColor = shapeStrokeColor
//shadowShape.lineWidth = strokeLinesetting
shadowView.layer.addSublayer(shadowShape)
backgroundView.addSubview(shadowView)

//圖層疊圖
//backgroundView.addSubview(imageView)
backgroundView.addSubview(tailView)
backgroundView.addSubview(frontTailView)
backgroundView.addSubview(footView2)
backgroundView.addSubview(footLineView2)
backgroundView.addSubview(footView1)
backgroundView.addSubview(footLineView1)
backgroundView.addSubview(handView2)
backgroundView.addSubview(bodyView)
backgroundView.addSubview(earView2)
backgroundView.addSubview(earTopView2)
backgroundView.addSubview(earView1)
backgroundView.addSubview(earTopView1)
backgroundView.addSubview(headView)
backgroundView.addSubview(headLineView)
backgroundView.addSubview(handView1)
backgroundView.addSubview(shadowView)
backgroundView.addSubview(bodyLineView)
backgroundView.addSubview(eyeView2)
backgroundView.addSubview(eyeView1)
backgroundView.addSubview(eyePupilView2)
backgroundView.addSubview(eyePupilView1)
backgroundView.addSubview(noseView)
backgroundView.addSubview(blushView2)
backgroundView.addSubview(blushView1)
backgroundView.addSubview(mouthView)
backgroundView.addSubview(mouthTopView)
backgroundView.addSubview(tongueView)
backgroundView.addSubview(mouthShadowView)

PlaygroundPage.current.liveView = backgroundView
